<!-- JQUERY -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<!-- BOOTSTRAP JS -->
<script
    src="<?php echo base_url() ?>assets/build/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- SWIPER JS -->
<script src="<?php echo base_url() ?>assets/build/assets/libs/swiper/swiper-bundle.min.js"></script>

<!-- INTERNAL AUTHENTICATION JS -->
<link rel="modulepreload" href="<?php echo base_url() ?>assets/build/assets/authentication-fa6f6b78.js" />
<script type="module"
    src="<?php echo base_url() ?>assets/build/assets/authentication-fa6f6b78.js"></script>

<!-- SHOW PASSWORD JS -->
<script src="<?php echo base_url() ?>assets/build/assets/show-password.js"></script>

<!--TOAST CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.min.js"></script>
