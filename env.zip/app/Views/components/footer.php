<!-- SCROLL-TO-TOP -->
<div class="scrollToTop">
  <span class="arrow"><i class="ri-arrow-up-s-fill fs-20"></i></span>
</div>
<div id="responsive-overlay"></div>

<!-- LOADER -->
<div id="loader">
    <img src="<?= base_url() ?>assets/build/assets/images/media/loader.svg" alt="">
</div>

<!-- JS LOADER -->
<?php require ('basic_js.php') ?>