<head>

    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=no'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="Description">
    <meta name="Author">
    <meta name="keywords" content="">

    <!-- FAVICON -->
    <link rel="icon" href="<?= base_url() ?>assets/custom/img/favicon.png">

    <!-- CSS LOADER -->
    <?php require ('basic_css.php') ?>

    <script>
        var base_url = "<?= base_url();?>"
    </script>

</head>